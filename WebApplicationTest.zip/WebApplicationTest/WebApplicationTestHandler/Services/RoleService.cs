﻿using WebApplicationTestHandler.Models.Entities;
using WebApplicationTestHandler.Models.ViewModels;
using WebApplicationTestHandler.Services.Interfaces;
using Kendo.Mvc;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplicationTestHandler.Services
{
    public class RoleService : IRoleService, IDisposable
    {
        private testDBContext _context;
        private HttpContext _httpContext;
        public RoleService(testDBContext context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContext = httpContextAccessor.HttpContext;

        }

        public async Task<DataSourceResult> GetRequestedRoles(DataSourceRequest request)
        {
            DataSourceResult requestedUsers = null;

            try
            {
                //get the Users data from database
                var listOfUsers = from r in _context.Roles
                                  select new RoleViewModel()
                                  {
                                      Id = r.Id,
                                      Name = r.Name,
                                      AdminLevel = r.AdminLevel,
                                      DefaultRole = r.DefaultRole,
                                      Description = r.Description
                                  };

                requestedUsers = await listOfUsers.ToDataSourceResultAsync(request);
            }
            catch (Exception ex)
            {
                throw;
            }

            return requestedUsers;
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
