﻿using WebApplicationTestHandler.Models.Entities;
using WebApplicationTestHandler.Models.ViewModels;
using WebApplicationTestHandler.Services.Interfaces;
using Kendo.Mvc;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplicationTestHandler.Extensions;
using WebApplicationTestHandler.Extensions;

namespace WebApplicationTestHandler.Services
{
    public class UserService : IUserService, IDisposable
    {
        private testDBContext _context;
        private HttpContext _httpContext;
        public UserService(testDBContext context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContext = httpContextAccessor.HttpContext;

        }
        public async Task AddUser(UserViewModel userView)
        {
            if (userView != null)
            {
                //check for existing User login
                var userEntity = _context.Users.Where(u => u.LoginName == userView.LoginName).SingleOrDefault();

                if (userEntity != null)
                {
                    if (userEntity.ApplicationUser)
                    {
                        //The User login already exist
                        string strErrMsg = "ERR_USER_LOGIN_EXIST";
                        throw new Exception(strErrMsg);
                    }
                    userView.Id = userEntity.Id;
                }
                userView.ApplicationUser = true;
                await AddOrModifyUser(userView);
            }
        }
        public async Task<UserViewModel> GetUserByID(int Id)
        {
            UserViewModel userView = null;

            try
            {
                User userItem = await (from u in _context.Users
                                        where u.Id.Equals(Id)
                                        select u).SingleOrDefaultAsync();

                if (userItem != null)
                {
                    //map to view model                    
                    userView = userItem.ToViewModel();

                    Location loc = _context.Locations.Where(l => l.Id.Equals(Convert.ToInt32(userItem.Location))).SingleOrDefault();

                    userView.Location = loc == null ? string.Empty : loc.Name;
                                                           
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return userView;
        }
        private async Task<UserViewModel> AddOrModifyUser(UserViewModel userView)
        {
            User userEntity = null;

            try
            {
                var strategy = _context.Database.CreateExecutionStrategy();
                await strategy.Execute(async () =>
                {
                    using (var dbContextTransaction = _context.Database.BeginTransaction())
                    {

                        //Check for Add or Modify procedure
                        if (userView.Id == 0)
                        {
                            //Add new user to DB
                            userEntity = userView.ToEntity();
                            userEntity.CreationDate = DateTime.Now;
                            userEntity.Location = await GetLocationId(userView.Location);
                            _context.Entry(userEntity).State = EntityState.Added;
                        }
                        else
                        {
                            //get the User from DB
                            userEntity = await _context.Users.SingleOrDefaultAsync(u => u.Id == userView.Id);

                            userEntity.FirstName = userView.FirstName;
                            userEntity.LastName = userView.LastName;
                            userEntity.Email = userView.Email;
                            userEntity.Phone = userView.Phone;
                            userEntity.Location = await GetLocationId(userView.Location);
                            userEntity.ApplicationUser = userView.ApplicationUser;
                            userEntity.IsActive = userView.IsActive;
                            _context.Entry(userEntity).State = EntityState.Modified;
                        }
                        await _context.SaveChangesWithValidationAsync();
                        userView.Id = userEntity.Id;

                                               
                        //Save the modifications
                        await _context.SaveChangesWithValidationAsync();
                        dbContextTransaction.Commit();

                    }
                });


            }
            catch (Exception ex)
            {
                throw;
            }
            return userView;
        }
        private async Task<int?> GetLocationId(string location)
        {
            if (string.IsNullOrEmpty(location))
                return null;

            //verify if location exists
            Location locationEntity = await _context.Locations.Where(l => l.Name.Equals(location)).FirstOrDefaultAsync();
            if (locationEntity == null)
            {
                //add location to DB
                locationEntity = new Location()
                {
                    Name = location,
                    Active = 1
                };
                _context.Entry(locationEntity).State = EntityState.Added;
                _context.SaveChangesWithValidation();
            }
            return locationEntity.Id;
        }
        public async Task<DataSourceResult> GetRequestedUsers(DataSourceRequest request)
        {
            DataSourceResult requestedUsers = null;

            try
            {
                //get the Users data from database
                var listOfUsers = from u in _context.Users
                                  join l in _context.Locations on u.Location equals l.Id
                                  where u.ApplicationUser == true && u.IsActive == true
                                  select new UserViewModel()
                                  {
                                      Id = u.Id,
                                      LoginName = u.LoginName,                                     
                                      FirstName = u.FirstName,
                                      LastName = u.LastName,
                                      Email = u.Email,                                    
                                      Phone = u.Phone,                                    
                                      Location = l.Name                                  
                                  };

                requestedUsers = await listOfUsers.ToDataSourceResultAsync(request);
            }
            catch (Exception ex)
            {
                throw;
            }

            return requestedUsers;
        }
        public async Task<UserViewModel> GetUserByUserLogin(string UserLogin)
        {
            UserViewModel userView = null;

            try
            {
                
                    userView = await GetUserByUserInformation(userView);
                
            }
            catch (Exception ex)
            {

                throw;
            }

            return userView;
        }
        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
