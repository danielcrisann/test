﻿using System.Collections.Generic;
using System.Threading.Tasks;
using WebApplicationTestHandler.Models.ViewModels;

namespace WebApplicationTestHandler.Services.Interfaces
{
    public interface ICurrentUserService
    {
        bool CurrentUserIsSet();
        Task SetCurrentUser(string userLogin);
        UserViewModel GetCurrentUser();
    }
}
