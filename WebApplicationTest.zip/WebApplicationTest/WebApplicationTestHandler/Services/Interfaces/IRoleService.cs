﻿using System.Collections.Generic;
using Kendo.Mvc.UI;
using System.Threading.Tasks;
using WebApplicationTestHandler.Models.ViewModels;

namespace WebApplicationTestHandler.Services.Interfaces
{
    public interface IRoleService
    {
        Task<DataSourceResult> GetRequestedRoles(DataSourceRequest request);
    }
}
