﻿namespace WebApplicationTestHandler.Services.Interfaces
{
    public interface IApplicationNameIdentityService
    {
        string GetApplicationNameIdentity();
        string GetApplicationLongName();
    }
}
