﻿//using System.Collections.Generic;
//using Kendo.Mvc.UI;
//using System.Threading.Tasks;
//using eSignHandler.Models.ViewModels;

using Kendo.Mvc.UI;
using WebApplicationTestHandler.Models.ViewModels;

namespace WebApplicationTestHandler.Services.Interfaces
{
    public interface IMovieService
    {
        Task AddMovie(MovieViewModel userView);
        Task<MovieViewModel> GetMovieByID(int Id);
        //Task<MovieViewModel> GetUserByMovieLogin(string UserLogin);
        Task<DataSourceResult> GetRequestedMovies(DataSourceRequest request);
    }
}
