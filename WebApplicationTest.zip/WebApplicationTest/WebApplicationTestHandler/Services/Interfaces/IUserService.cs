﻿using System.Collections.Generic;
using Kendo.Mvc.UI;
using System.Threading.Tasks;
using WebApplicationTestHandler.Models.ViewModels;

namespace WebApplicationTestHandler.Services.Interfaces
{
    public interface IUserService
    {
        Task AddUser(UserViewModel userView);
        Task<UserViewModel> GetUserByID(int Id);
        Task<DataSourceResult> GetRequestedUsers(DataSourceRequest request);
        Task<UserViewModel> GetUserByUserLogin(string UserLogin);
    }
}
