﻿using System;
using System.Linq;
using Microsoft.Extensions.Configuration;
using WebApplicationTestHandler.Services.Interfaces;

namespace WebApplicationTestHandler.Services
{
    public class ApplicationNameIdentityService : IApplicationNameIdentityService
    {
        private static string applicationNameIdentity = string.Empty;
        private static string applicationLongName = string.Empty;
        public ApplicationNameIdentityService(IConfiguration configuration)
        {
            // read application parameter
            var _applicationNameIdentity = configuration.AsEnumerable()
                .FirstOrDefault(r => r.Key.Equals("ApplicationNameIdentity"))
                .Value;

           
            applicationNameIdentity = _applicationNameIdentity;
            var _applicationLongName = configuration.AsEnumerable()
                .FirstOrDefault(r => r.Key.Equals("ApplicationLongName"))
                .Value;
            if (!string.IsNullOrEmpty(_applicationLongName))
            {
                applicationLongName = _applicationLongName;
            }
        }
        /// <summary>
        /// GetApplicationNameIdentity: method used to return application name identity
        /// </summary>
        /// <returns>Return application name identity string</returns>
        public string GetApplicationNameIdentity()
        {
            return applicationNameIdentity;
        }
        /// <summary>
        /// GetApplicationNameIdentity: method used to return application name identity
        /// </summary>
        /// <returns>Return application name identity string</returns>
        public string GetApplicationLongName()
        {
            return applicationLongName;
        }
    }
}

