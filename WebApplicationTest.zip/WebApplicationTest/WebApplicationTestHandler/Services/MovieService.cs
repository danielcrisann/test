﻿//using eSignHandler.Extensions;
//using eSignHandler.Models.Entities;
//using eSignHandler.Models.EntitiesReadOnly;
//using eSignHandler.Models.ViewModels;
using WebApplicationTestHandler.Services.Interfaces;
//using Kendo.Mvc;
//using Kendo.Mvc.Extensions;
//using Kendo.Mvc.UI;
//using Microsoft.AspNetCore.Http;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.Extensions.DependencyInjection;
//using Microsoft.Extensions.Logging;
//using NLog;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
using WebApplicationTestHandler.Models.Entities;
using Microsoft.AspNetCore.Http;
using Kendo.Mvc.UI;
using Kendo.Mvc;
using WebApplicationTestHandler.Models.ViewModels;
using Kendo.Mvc.Extensions;
using WebApplicationTestHandler.Extensions;
using Microsoft.EntityFrameworkCore;

namespace WebApplicationTestHandler.Services
{
    public class MovieService : IMovieService, IDisposable
    {
        
        private testDBContext _context;
        private HttpContext _httpContext;
              
        public MovieService(testDBContext context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContext = httpContextAccessor.HttpContext;
        }
        public async Task<DataSourceResult> GetRequestedMovies(DataSourceRequest request)
        {
            DataSourceResult requestedUsers = null;

            try
            {
                //get the Users data from database
                var listOfUsers = from m in _context.Movies
                                  //join ui in _context.UserInfo on u.UserInfoId equals ui.Id
                                  //where m.ApplicationUser == true
                                  select new MovieViewModel()
                                  {
                                      Id = m.Id,
                                      Name = m.Name,
                                      Genre = m.Genre,
                                      Rating = m.Rating,
                                      MovieYear = m.MovieYear
                                  };

                requestedUsers = await listOfUsers.ToDataSourceResultAsync(request);
            }
            catch (Exception ex)
            {
                throw;
            }

            return requestedUsers;
        }
        public async Task AddMovie(MovieViewModel movieView)
        {
            try
            {
                if (movieView != null)
                {
                    Movie MovieEntity = movieView.ToEntity();
                    _context.Movies.Add(MovieEntity);
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public async Task<MovieViewModel> GetMovieByID(int Id)
        {
            Movie movieEntity = await _context.Movies.Where(w => w.Id == Id).SingleOrDefaultAsync();
            MovieViewModel languageView = movieEntity.ToViewModel();

            return languageView;
        }









        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
