﻿using System;
using System.Collections.Generic;

namespace WebApplicationTestHandler.Models.Entities
{
    public partial class Role
    {
        public Role()
        {
            UsersRoles = new HashSet<UsersRole>();
        }

        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public int AdminLevel { get; set; }
        public bool DefaultRole { get; set; }
        public string? Description { get; set; }

        public virtual ICollection<UsersRole> UsersRoles { get; set; }
    }
}
