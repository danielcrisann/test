﻿using System;
using System.Collections.Generic;

namespace WebApplicationTestHandler.Models.Entities
{
    public partial class Actor
    {
        public int Id { get; set; }
        public string FirstName { get; set; } = null!;
        public string LastName { get; set; } = null!;
        public int MovieId { get; set; }

        public virtual Movie Movie { get; set; } = null!;
    }
}
