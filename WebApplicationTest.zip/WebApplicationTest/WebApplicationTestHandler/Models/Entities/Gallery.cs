﻿using System;
using System.Collections.Generic;

namespace WebApplicationTestHandler.Models.Entities
{
    public partial class Gallery
    {
        public int Id { get; set; }
        public int MovieId { get; set; }
        public byte[]? ImageGallery { get; set; }

        public virtual Movie Movie { get; set; } = null!;
    }
}
