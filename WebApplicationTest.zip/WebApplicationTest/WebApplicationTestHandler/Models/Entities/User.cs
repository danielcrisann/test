﻿using System;
using System.Collections.Generic;

namespace WebApplicationTestHandler.Models.Entities
{
    public partial class User
    {
        public User()
        {
            UsersRoles = new HashSet<UsersRole>();
        }

        public int Id { get; set; }
        public string LoginName { get; set; } = null!;
        public string FirstName { get; set; } = null!;
        public string LastName { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string? Phone { get; set; }
        public int? Location { get; set; }
        public DateTime CreationDate { get; set; }
        public bool ApplicationUser { get; set; }
        public bool? IsActive { get; set; }

        public virtual Location? LocationNavigation { get; set; }
        public virtual ICollection<UsersRole> UsersRoles { get; set; }
    }
}
