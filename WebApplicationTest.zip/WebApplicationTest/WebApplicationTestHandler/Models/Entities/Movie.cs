﻿using System;
using System.Collections.Generic;

namespace WebApplicationTestHandler.Models.Entities
{
    public partial class Movie
    {
        public Movie()
        {
            Actors = new HashSet<Actor>();
            Comments = new HashSet<Comment>();
            Galleries = new HashSet<Gallery>();
        }

        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public string? Genre { get; set; }
        public decimal? Rating { get; set; }
        public DateTime? DateCreate { get; set; }
        public int? MovieYear { get; set; }
        public string? Description { get; set; }

        public virtual ICollection<Actor> Actors { get; set; }
        public virtual ICollection<Comment> Comments { get; set; }
        public virtual ICollection<Gallery> Galleries { get; set; }
    }
}
