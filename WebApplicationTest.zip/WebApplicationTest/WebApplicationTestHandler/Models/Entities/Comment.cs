﻿using System;
using System.Collections.Generic;

namespace WebApplicationTestHandler.Models.Entities
{
    public partial class Comment
    {
        public int Id { get; set; }
        public int MovieId { get; set; }
        public string? Description { get; set; }

        public virtual Movie Movie { get; set; } = null!;
    }
}
