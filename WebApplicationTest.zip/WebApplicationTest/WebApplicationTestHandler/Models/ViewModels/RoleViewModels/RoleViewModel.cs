﻿using System;
using System.Collections.Generic;

namespace WebApplicationTestHandler.Models.ViewModels
{
    public class RoleViewModel
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public int AdminLevel { get; set; }
        public bool DefaultRole { get; set; }
        public string? Description { get; set; }      
    }
}
