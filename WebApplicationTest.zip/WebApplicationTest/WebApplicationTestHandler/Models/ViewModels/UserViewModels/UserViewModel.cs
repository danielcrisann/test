﻿using System;
using System.Collections.Generic;

namespace WebApplicationTestHandler.Models.ViewModels
{
    public class UserViewModel
    {
        public int Id { get; set; }
        public string? LoginName { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Email { get; set; }
        public string? Phone { get; set; }
        public string? Location { get; set; }
        public DateTime CreationDate { get; set; }
        public bool ApplicationUser { get; set; }
        public bool IsActive { get; set; } = true;
        //public string? Roles { get; set; }
        //public List<UserRoleViewModel> UserRoles { get; set; }
    }
}
