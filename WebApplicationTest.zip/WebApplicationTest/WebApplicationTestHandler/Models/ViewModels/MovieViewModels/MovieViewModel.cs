﻿using System;
using System.Collections.Generic;

namespace WebApplicationTestHandler.Models.ViewModels
{
    public class MovieViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public string? Genre { get; set; }
        public decimal? Rating { get; set; }
       // public DateTime? DateCreate { get; set; }
        public int? MovieYear { get; set; }
    }
}
