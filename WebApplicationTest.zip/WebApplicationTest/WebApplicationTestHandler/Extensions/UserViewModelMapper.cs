﻿using WebApplicationTestHandler.Models.Entities;
using WebApplicationTestHandler.Models.ViewModels;

namespace WebApplicationTestHandler.Extensions
{
    public static class UserViewModelMapper
    {
        public static UserViewModel ToViewModel(this User entity)
        {
            return entity == null ? new UserViewModel()
            {
                Id = entity.Id,
            }
            : new UserViewModel
            {
                Id = entity.Id,
                LoginName = entity.LoginName,
                FirstName = entity.FirstName,
                LastName = entity.LastName,
                Email = entity.Email,
                Phone = entity.Phone,
                CreationDate = entity.CreationDate,
                //IsActive = entity.IsActive
            };
        }

        public static User ToEntity(this UserViewModel viewModel)
        {
            return viewModel == null ? null : new User
            {
                Id = viewModel.Id,
                LoginName = viewModel.LoginName,
                FirstName = viewModel.FirstName,
                LastName = viewModel.LastName,
                Email = viewModel.Email,
                Phone = viewModel.Phone,
                CreationDate = viewModel.CreationDate,
                ApplicationUser = viewModel.ApplicationUser,
                //IsActive = viewModel.IsActive
            };
        }
    }
}
