﻿using WebApplicationTestHandler.Models.Entities;
using WebApplicationTestHandler.Models.ViewModels;

namespace WebApplicationTestHandler.Extensions
{
    public static class MovieViewModelMapper
    {
        public static MovieViewModel ToViewModel(this Movie entity)
        {
            return entity == null ? new MovieViewModel()
            {
                Id = entity.Id,
            }
            : new MovieViewModel
            {
                Id = entity.Id,
                Name = entity.Name,
                Genre = entity.Genre,
                MovieYear = entity.MovieYear,
                Rating = entity.Rating,
            };
        }

        public static Movie ToEntity(this MovieViewModel viewModel)
        {
            return viewModel == null ? null : new Movie
            {
                Id = viewModel.Id,
                Name = viewModel.Name,
                Genre = viewModel.Genre,
                MovieYear = viewModel.MovieYear,
                Rating = viewModel.Rating
            };
        }
    }
}
