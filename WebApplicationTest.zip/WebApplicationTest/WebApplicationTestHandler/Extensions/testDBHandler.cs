﻿using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplicationTestHandler.Extensions
{
    public static class testDBHandler
    {
        public static void SaveChangesWithValidation(this DbContext dbContext)
        {
            try
            {
                dbContext.SaveChanges();
            }
            catch (DbUpdateException dbExU)
            {
                string strErrMsg = dbExU.InnerException.Message;

                //dbContext.RollbackDBChanges();

                if (strErrMsg != "")
                    throw new Exception(strErrMsg);
                else
                    throw new Exception("Unknown DB exception!", dbExU);
            }
            catch
            {
                throw;
            }
        }
        public static async Task SaveChangesWithValidationAsync(this DbContext dbContext)
        {
            try
            {
                await dbContext.SaveChangesAsync();
            }
            catch (DbUpdateException dbExU)
            {
                string strErrMsg = dbExU.InnerException.Message;

                if (strErrMsg != "")
                    throw new Exception(strErrMsg);
                else
                    throw new Exception("Unknown DB exception!", dbExU);
            }
            catch
            {
                throw;
            }
        }
        private static void RollbackDBChanges(this DbContext dbContext)
        {
            var changedEntries = dbContext.ChangeTracker.Entries().Where(x => x.State != EntityState.Unchanged).ToList();

            foreach (var entry in changedEntries)
            {
                switch (entry.State)
                {
                    case EntityState.Modified:
                        entry.State = EntityState.Unchanged;
                        break;
                    case EntityState.Added:
                        entry.State = EntityState.Detached;
                        break;
                    case EntityState.Deleted:
                        entry.State = EntityState.Unchanged;
                        break;
                }
            }
        }        
    }
}
